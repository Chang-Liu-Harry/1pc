import React from 'react';

const NoticeBar = () => {
  return (
    <div className="bg-blue-500 text-white p-4 text-center">
      <p>
        Tips: Using <strong>**your wish here**</strong> in your messages will be interpreted by the AI as events that have already happened. You know what I mean? 😉
      </p>
    </div>
  );
}

export default NoticeBar;
