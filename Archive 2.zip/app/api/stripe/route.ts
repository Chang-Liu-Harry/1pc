import { auth, currentUser } from "@clerk/nextjs";
import { NextResponse } from "next/server";

import prismadb from "@/lib/prismadb";
import { stripe } from "@/lib/stripe";
import { absoluteUrl } from "@/lib/utils";

const settingsUrl = absoluteUrl("/settings");

// Mapping plan IDs to Stripe price data
const priceMapping: Record<string, any> = {
  "12_month": {
    currency: "USD",
    product_data: {
      name: "OnepieceAI.Chat Monthly Subscription",
      description: "Yearly Access ",
    },
    unit_amount: 599,
    recurring: {
      interval: "month",
      interval_count: 12,
    },
  },
  "3_month": {
    currency: "USD",
    product_data: {
      name: "OnepieceAI.Chat Monthly Subscription",
      description: "Quarterly Access ",
    },
    unit_amount: 999,
    recurring: {
      interval: "month",
      interval_count: 3,
    },
  },
  "1_month": {
    currency: "USD",
    product_data: {
      name: "OnepieceAI.Chat Monthly Subscription",
      description: "Monthly Access ",
    },
    unit_amount: 1299,
    recurring: {
      interval: "month",
    },
  },
};

export async function POST(req: Request) {
  try {
    const { userId } = auth();
    const user = await currentUser();
    const { planId } = await req.json(); // Get the planId from the request body

    if (!userId || !user) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const userSubscription = await prismadb.userSubscription.findUnique({
      where: {
        userId,
      },
    });

    if (userSubscription && userSubscription.stripeCustomerId) {
      const stripeSession = await stripe.billingPortal.sessions.create({
        customer: userSubscription.stripeCustomerId,
        return_url: settingsUrl,
      });

      return new NextResponse(JSON.stringify({ url: stripeSession.url }));
    }

    const priceData = priceMapping[planId];
    if (!priceData) {
      return new NextResponse("Invalid plan ID", { status: 400 });
    }

    const stripeSession = await stripe.checkout.sessions.create({
      success_url: settingsUrl,
      cancel_url: settingsUrl,
      payment_method_types: ["card"],
      mode: "subscription",
      billing_address_collection: "auto",
      customer_email: user.emailAddresses[0].emailAddress,
      line_items: [
        {
          price_data: priceData,
          quantity: 1,
        },
      ],
      metadata: {
        userId,
      },
    });

    return new NextResponse(JSON.stringify({ url: stripeSession.url }));
  } catch (error) {
    console.log("[STRIPE]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
};
