import axios from "axios";
import { useState } from "react";
import { useToast } from "@/components/ui/use-toast";

export const SubscriptionButton = ({ isPro = false, selectedPlanId }: { isPro: boolean; selectedPlanId: string; }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const onClick = async () => {
    try {
      setLoading(true);

      const response = await axios.post("/api/stripe", { planId: selectedPlanId });

      window.location.href = response.data.url;
    } catch (error) {
      toast({
        description: "Something went wrong",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      className="bg-pink-600 hover:bg-pink-700 text-white py-2 px-6 rounded-md"
      disabled={loading}
      onClick={onClick}
    >
      {isPro ? "Manage Subscription" : "Upgrade"}
    </button>
  );
};
